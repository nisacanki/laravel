<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Deneme</title>
</head>
<body>
    <from action="<?php echo e(route('sonuc')); ?>" method="post">
        <?php echo csrf_field(); ?> 

        <textarea name="metin" style="width:300px; height:200px;"></textarea><br>
        <input type="submit" name="ilet" value="Gönder">

   </form>
</body>
</html>
<?php /**PATH C:\Users\nisac\lrvprojem\resources\views/form.blade.php ENDPATH**/ ?>