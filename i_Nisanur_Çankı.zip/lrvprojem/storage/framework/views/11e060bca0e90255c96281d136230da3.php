<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>İletişim Formu</title>
</head>
<body>
    <from action="<?php echo e(route('iletisim-sonuc')); ?>" method="post">
        <?php echo csrf_field(); ?> 
        <label>Ad Soyad</label><br>
        <input type="text" name="adsoyad"><br>
        <label>Telefon</label><br>
        <input type="text" name="telefon"><br>
        <label>E-mail</label><br>
        <input type="text" name="mail"><br>
        <label>Mesaj</label><br>
        <textarea name="metin" style="width:300px; height:200px;"></textarea><br>
        <input type="submit" name="ilet" value="Gönder">

   </form>
</body>
</html><?php /**PATH C:\Users\nisac\lrvprojem\resources\views/iletisim.blade.php ENDPATH**/ ?>