<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Resim Upload Uygulamsı</title>
</head>
<body>
   <form action="<?php echo e(route('yükle')); ?>" methoh="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label>Resim seciniz</label><br>
    <input type="file" name="resim"><br><br><br>
    <input type="sumbit" name="ilet" value="Resim yükle">
</form>
</body>
</html><?php /**PATH C:\Users\nisac\lrvprojem\resources\views/upload.blade.php ENDPATH**/ ?>