<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bilgiler;

class Modelislemleri extends Controller
{
    public function liste()
    {
        $bilgi=Bilgiler::find(2);

        echo $bilgi->metin;
    }
    public function ekle()
    {
        Bilgiler::create([
            "metin"=>"Model dosyasından eklendi.",
        ]);
    }
    public function guncelle()
    {
        Bilgiler::whereId(6)->update([
            "metin"=>"Model günceldir.",
        ]);
    }
    public function sil()
    {
        Bilgiler::whereId(6)->delete();
    }
}
