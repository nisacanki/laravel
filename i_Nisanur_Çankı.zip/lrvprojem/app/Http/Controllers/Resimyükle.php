<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Resimyükle extends Controller
{
    public function resimYükleme(Request $request)
    {
        echo $request->resim->getClientOriginalExtension();
    }
}
