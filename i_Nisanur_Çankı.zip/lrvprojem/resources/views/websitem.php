<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com -->
<!-- Last Published: Thu Sep 07 2023 14:21:47 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="template-versus.webflow.io" data-wf-page="560f27977849849d0e1fee5d" data-wf-site="560f27977849849d0e1fee5c">
    <head>
        <meta charset="utf-8"/>
        <title>Versus Template</title>
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="Webflow" name="generator"/>
        <link href="https://assets.website-files.com/560f27977849849d0e1fee5c/css/template-versus.webflow.97c0c0492.css" rel="stylesheet" type="text/css"/>
        <link href="https://fonts.googleapis.com" rel="preconnect"/>
        <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous"/>
        <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
        <script type="text/javascript">
            WebFont.load({
                google: {
                    families: ["Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic", "Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic"]
                }
            });
        </script>
        <script type="text/javascript">
            !function(o, c) {
                var n = c.documentElement
                  , t = " w-mod-";
                n.className += t + "js",
                ("ontouchstart"in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch")
            }(window, document);
        </script>
        <link href="https://assets.website-files.com/img/favicon.ico" rel="shortcut icon" type="image/x-icon"/>
        <link href="https://assets.website-files.com/img/webclip.png" rel="apple-touch-icon"/>
    </head>
    <body>
        <div class="hero">
            <div data-collapse="medium" data-animation="default" data-duration="400" data-easing="ease" data-easing2="ease" role="banner" class="nav w-nav">
                <div class="w-container">
                    <a href="#" class="logo w-nav-brand">
                        <div>Nisanur</div>
                    </a>
                    <nav role="navigation" class="nav-menu w-nav-menu">
                        <a href="/" aria-current="page" class="nav-link w-nav-link w--current">Portfolio</a>
                        <a href="/about" class="nav-link w-nav-link">About</a>
                        <a href="/contact" class="nav-link w-nav-link">Contact</a>
                    </nav>
                    <div class="menu-button w-nav-button">
                        <div class="w-icon-nav-menu"></div>
                    </div>
                </div>
            </div>
            <div class="heading-wrapper w-container">
                <h1 class="main-heading">Merhaba web ve mobil uygulamalar yapıyoruz</h1>
                <a href="/contact" class="button w-button">Fiyat teklifi alın.</a>
            </div>
        </div>
        <div class="section">
            <div class="w-container">
                <h3 class="section-title">Son çalısmalar</h3>
                <div class="w-dyn-list">
                    <div role="list" class="w-dyn-items w-row">
                        <div role="listitem" class="w-dyn-item w-col w-col-4">
                            <a href="/projects/music-player" class="w-inline-block">
                                <img alt="" src="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148d518924f1f620d590e3_zip-code-800.jpg" sizes="(max-width: 767px) 96vw, (max-width: 991px) 229.328125px, 299.984375px" srcset="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148d518924f1f620d590e3_zip-code-800-p-800x.jpeg 800w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148d518924f1f620d590e3_zip-code-800.jpg 800w" class="project-image"/>
                            </a>
                        </div>
                        <div role="listitem" class="w-dyn-item w-col w-col-4">
                            <a href="/projects/console-app" class="w-inline-block">
                                <img alt="" src="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56147659a92a0f0d59878a02_thum.png" sizes="(max-width: 767px) 96vw, (max-width: 991px) 229.328125px, 299.984375px" srcset="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56147659a92a0f0d59878a02_thum-p-500x.png 500w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/56147659a92a0f0d59878a02_thum.png 800w" class="project-image"/>
                            </a>
                        </div>
                        <div role="listitem" class="w-dyn-item w-col w-col-4">
                            <a href="/projects/infographic" class="w-inline-block">
                                <img alt="" src="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b4b8924f1f620d590b6_cthulu_van_v2.jpg" sizes="(max-width: 767px) 96vw, (max-width: 991px) 229.328125px, 299.984375px" srcset="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b4b8924f1f620d590b6_cthulu_van_v2-p-800x.jpeg 800w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b4b8924f1f620d590b6_cthulu_van_v2.jpg 800w" class="project-image"/>
                            </a>
                        </div>
                        <div role="listitem" class="w-dyn-item w-col w-col-4">
                            <a href="/projects/sports-car-app" class="w-inline-block">
                                <img alt="" src="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b65a38c7c456668150c_fan.png" sizes="(max-width: 767px) 96vw, (max-width: 991px) 229.328125px, 299.984375px" srcset="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b65a38c7c456668150c_fan-p-500x.png 500w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b65a38c7c456668150c_fan-p-800x.png 800w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b65a38c7c456668150c_fan.png 800w" class="project-image"/>
                            </a>
                        </div>
                        <div role="listitem" class="w-dyn-item w-col w-col-4">
                            <a href="/projects/music-app" class="w-inline-block">
                                <img alt="" src="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b8e8924f1f620d590bd_human.jpg" sizes="(max-width: 767px) 96vw, (max-width: 991px) 229.328125px, 299.984375px" srcset="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b8e8924f1f620d590bd_human-p-500x.jpeg 500w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b8e8924f1f620d590bd_human-p-800x.jpeg 800w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148b8e8924f1f620d590bd_human.jpg 800w" class="project-image"/>
                            </a>
                        </div>
                        <div role="listitem" class="w-dyn-item w-col w-col-4">
                            <a href="/projects/photo-app-icon" class="w-inline-block">
                                <img alt="" src="https://assets.website-files.com/56104995fd4f22cf7e335ea0/5614744aa92a0f0d598789c0_dribbble.png" sizes="(max-width: 767px) 96vw, (max-width: 991px) 229.328125px, 299.984375px" srcset="https://assets.website-files.com/56104995fd4f22cf7e335ea0/5614744aa92a0f0d598789c0_dribbble-p-500x.png 500w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/5614744aa92a0f0d598789c0_dribbble-p-800x.png 800w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/5614744aa92a0f0d598789c0_dribbble.png 800w" class="project-image"/>
                            </a>
                        </div>
                        <div role="listitem" class="w-dyn-item w-col w-col-4">
                            <a href="/projects/news-feed" class="w-inline-block">
                                <img alt="" src="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148bc1a38c7c456668151a_sans_titre_-_17-01.png" sizes="(max-width: 767px) 96vw, (max-width: 991px) 229.328125px, 299.984375px" srcset="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148bc1a38c7c456668151a_sans_titre_-_17-01-p-500x.png 500w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148bc1a38c7c456668151a_sans_titre_-_17-01.png 800w" class="project-image"/>
                            </a>
                        </div>
                        <div role="listitem" class="w-dyn-item w-col w-col-4">
                            <a href="/projects/photo-app" class="w-inline-block">
                                <img alt="" src="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148bf08924f1f620d590c2_astrav1.jpg" sizes="(max-width: 767px) 96vw, (max-width: 991px) 229.328125px, 299.984375px" srcset="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148bf08924f1f620d590c2_astrav1-p-800x.jpeg 800w, https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148bf08924f1f620d590c2_astrav1.jpg 800w" class="project-image"/>
                            </a>
                        </div>
                        <div role="listitem" class="w-dyn-item w-col w-col-4">
                            <a href="/projects/flat-design" class="w-inline-block">
                                <img alt="" src="https://assets.website-files.com/56104995fd4f22cf7e335ea0/56148c2e404247a362fcde2a_neighborhood.jpg" class="project-image"/>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="w-container">
                <div class="footer-logo">Web Sitesi</div>
                <div>Nisanur tarafından yapılmıştır</div>
            </div>
        </div>
        <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=560f27977849849d0e1fee5c" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
        <script src="https://assets.website-files.com/560f27977849849d0e1fee5c/js/webflow.d513ca016.js" type="text/javascript"></script>
    </body>
</html>
