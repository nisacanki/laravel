<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Resim Upload Uygulamsı</title>
</head>
<body>
   <form action="{{route('yükle')}}" methoh="post" enctype="multipart/form-data">
    @csrf
    <label>Resim seciniz</label><br>
    <input type="file" name="resim"><br><br><br>
    <input type="sumbit" name="ilet" value="Resim yükle">
</form>
</body>
</html>